import UIKit

/// Forge Keyboard — the extension.
///
/// The contract, enforced by construction:
///  1. No silent auto-substitution, ever. Text is inserted or
///     deleted only in direct response to a key tap. Suggestions
///     appear in the candidate bar (up to 3) and are applied only
///     when a candidate is tapped. Space and punctuation insert
///     themselves and nothing else.
///  2. No key flicks, no long-press alternates, no gesture input.
///     One tap, one character (or one named control action).
///  3. No Full Access, no networking. This file contains no
///     network calls; the extension's Info.plist sets
///     RequestsOpenAccess to false. Completion sources are the
///     on-device Lexicon and UITextChecker only.
final class KeyboardViewController: UIInputViewController {

    private enum ShiftState { case off, once, locked }
    private enum Layer { case letters, symbols }

    private var shiftState: ShiftState = .off
    private var layer: Layer = .letters

    private var candidateBar: UIStackView!
    private var candidateButtons: [UIButton] = []
    private var currentCandidates: [String] = []
    private var keyboardStack: UIStackView!
    private var heightConstraint: NSLayoutConstraint?

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.08, alpha: 1)

        candidateBar = makeCandidateBar()
        keyboardStack = UIStackView()
        keyboardStack.axis = .vertical
        keyboardStack.spacing = 10
        keyboardStack.distribution = .fillEqually
        keyboardStack.translatesAutoresizingMaskIntoConstraints = false

        let root = UIStackView(arrangedSubviews: [candidateBar, keyboardStack])
        root.axis = .vertical
        root.spacing = 8
        root.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(root)
        NSLayoutConstraint.activate([
            root.topAnchor.constraint(equalTo: view.topAnchor, constant: 6),
            root.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 4),
            root.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -4),
            root.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -6),
        ])

        buildRows()
        updateCandidates()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if heightConstraint == nil {
            let h = view.heightAnchor.constraint(equalToConstant: 292)
            h.priority = .defaultHigh
            h.isActive = true
            heightConstraint = h
        }
    }

    override func textDidChange(_ textInput: UITextInput?) {
        super.textDidChange(textInput)
        updateCandidates()
    }

    // MARK: - Candidate bar

    private func makeCandidateBar() -> UIStackView {
        let bar = UIStackView()
        bar.axis = .horizontal
        bar.spacing = 6
        bar.distribution = .fillEqually
        bar.translatesAutoresizingMaskIntoConstraints = false
        bar.heightAnchor.constraint(equalToConstant: 38).isActive = true
        for i in 0..<3 {
            let b = UIButton(type: .system)
            b.tag = i
            b.titleLabel?.font = .systemFont(ofSize: 16)
            b.setTitleColor(UIColor(white: 0.92, alpha: 1), for: .normal)
            b.backgroundColor = UIColor(white: 0.16, alpha: 1)
            b.layer.cornerRadius = 6
            b.isHidden = true
            b.addTarget(self, action: #selector(candidateTapped(_:)), for: .touchUpInside)
            candidateButtons.append(b)
            bar.addArrangedSubview(b)
        }
        return bar
    }

    /// The word fragment immediately before the cursor. Word
    /// characters include & and ' so seeded entries like "AT&T"
    /// complete as a unit.
    private func currentWord() -> String {
        guard let ctx = textDocumentProxy.documentContextBeforeInput else { return "" }
        var chars: [Character] = []
        for ch in ctx.reversed() {
            if ch.isLetter || ch.isNumber || ch == "&" || ch == "'" || ch == "-" {
                chars.append(ch)
            } else {
                break
            }
        }
        return String(chars.reversed())
    }

    /// Prefix completion: personal lexicon first (exact-prefix,
    /// curated order), then UITextChecker completions, deduped,
    /// capped at 3. Results are only ever displayed — applying
    /// one requires candidateTapped(_:).
    private func updateCandidates() {
        let word = currentWord()
        var results: [String] = []
        if !word.isEmpty {
            let lower = word.lowercased()
            for entry in Lexicon.personal
            where entry.lowercased().hasPrefix(lower) && entry.lowercased() != lower {
                results.append(entry)
            }
            let checker = UITextChecker()
            let range = NSRange(location: 0, length: word.utf16.count)
            if let guesses = checker.completions(forPartialWordRange: range,
                                                 in: word, language: "en_US") {
                for g in guesses
                where !results.contains(where: { $0.lowercased() == g.lowercased() }) {
                    results.append(g)
                }
            }
        }
        currentCandidates = Array(results.prefix(3))
        for (i, b) in candidateButtons.enumerated() {
            if i < currentCandidates.count {
                b.setTitle(currentCandidates[i], for: .normal)
                b.isHidden = false
            } else {
                b.setTitle(nil, for: .normal)
                b.isHidden = true
            }
        }
    }

    @objc private func candidateTapped(_ sender: UIButton) {
        let index = sender.tag
        guard index < currentCandidates.count else { return }
        let replacement = currentCandidates[index]
        for _ in 0..<currentWord().count {
            textDocumentProxy.deleteBackward()
        }
        textDocumentProxy.insertText(replacement)
        updateCandidates()
    }

    // MARK: - Key rows

    private enum KeyKind {
        case letter(String)
        case text(String)          // digits & symbols: insert literally
        case shift, delete, space, returnKey, globe, toSymbols, toLetters
    }

    private struct KeySpec {
        let title: String
        let kind: KeyKind
        let width: CGFloat         // relative units within the row
    }

    private func buildRows() {
        for arranged in keyboardStack.arrangedSubviews {
            keyboardStack.removeArrangedSubview(arranged)
            arranged.removeFromSuperview()
        }
        let rows: [[KeySpec]] = (layer == .letters) ? letterRows() : symbolRows()
        for row in rows {
            keyboardStack.addArrangedSubview(makeRow(row))
        }
        refreshShiftAppearance()
    }

    private func letterRows() -> [[KeySpec]] {
        let letters: (String) -> [KeySpec] = { s in
            s.map { KeySpec(title: String($0), kind: .letter(String($0)), width: 1) }
        }
        return [
            letters("qwertyuiop"),
            letters("asdfghjkl"),
            [KeySpec(title: "⇧", kind: .shift, width: 1.5)]
                + letters("zxcvbnm")
                + [KeySpec(title: "⌫", kind: .delete, width: 1.5)],
            [
                KeySpec(title: "123", kind: .toSymbols, width: 1.5),
                KeySpec(title: "🌐", kind: .globe, width: 1),
                KeySpec(title: "space", kind: .space, width: 5),
                KeySpec(title: "return", kind: .returnKey, width: 2),
            ],
        ]
    }

    private func symbolRows() -> [[KeySpec]] {
        let texts: (String) -> [KeySpec] = { s in
            s.map { KeySpec(title: String($0), kind: .text(String($0)), width: 1) }
        }
        return [
            texts("1234567890"),
            [
                KeySpec(title: "-", kind: .text("-"), width: 1),
                KeySpec(title: "/", kind: .text("/"), width: 1),
                KeySpec(title: ":", kind: .text(":"), width: 1),
                KeySpec(title: ";", kind: .text(";"), width: 1),
                KeySpec(title: "(", kind: .text("("), width: 1),
                KeySpec(title: ")", kind: .text(")"), width: 1),
                KeySpec(title: "$", kind: .text("$"), width: 1),
                KeySpec(title: "&", kind: .text("&"), width: 1),
                KeySpec(title: "@", kind: .text("@"), width: 1),
                KeySpec(title: "\"", kind: .text("\""), width: 1),
            ],
            texts(".,?!'") + [KeySpec(title: "⌫", kind: .delete, width: 1.5)],
            [
                KeySpec(title: "ABC", kind: .toLetters, width: 1.5),
                KeySpec(title: "🌐", kind: .globe, width: 1),
                KeySpec(title: "space", kind: .space, width: 5),
                KeySpec(title: "return", kind: .returnKey, width: 2),
            ],
        ]
    }

    private func makeRow(_ specs: [KeySpec]) -> UIStackView {
        let row = UIStackView()
        row.axis = .horizontal
        row.spacing = 5
        row.distribution = .fill
        let total = specs.reduce(CGFloat(0)) { $0 + $1.width }
        for spec in specs {
            let b = makeKey(spec)
            row.addArrangedSubview(b)
            // Widths proportional to the spec's units; spacing makes
            // these approximations, which is fine for key sizing.
            let c = b.widthAnchor.constraint(
                equalTo: row.widthAnchor, multiplier: spec.width / total)
            c.priority = .defaultHigh
            c.isActive = true
        }
        return row
    }

    private func makeKey(_ spec: KeySpec) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(spec.title, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: spec.title.count > 1 ? 15 : 22)
        b.setTitleColor(UIColor(white: 0.95, alpha: 1), for: .normal)
        b.backgroundColor = UIColor(white: 0.28, alpha: 1)
        b.layer.cornerRadius = 6

        switch spec.kind {
        case .letter, .text:
            b.accessibilityIdentifier = spec.title
            b.addTarget(self, action: #selector(insertKey(_:)), for: .touchUpInside)
            // Store the literal on the button via its title; casing
            // is resolved at tap time for letters (see insertKey).
            if case .text(let s) = spec.kind { b.accessibilityValue = s }
            if case .letter(let s) = spec.kind { b.accessibilityValue = s }
        case .shift:
            b.accessibilityIdentifier = "shift"
            b.backgroundColor = UIColor(white: 0.18, alpha: 1)
            b.addTarget(self, action: #selector(shiftTapped), for: .touchUpInside)
        case .delete:
            b.backgroundColor = UIColor(white: 0.18, alpha: 1)
            b.addTarget(self, action: #selector(deleteTapped), for: .touchUpInside)
        case .space:
            b.backgroundColor = UIColor(white: 0.2, alpha: 1)
            b.addTarget(self, action: #selector(spaceTapped), for: .touchUpInside)
        case .returnKey:
            b.backgroundColor = UIColor(white: 0.18, alpha: 1)
            b.addTarget(self, action: #selector(returnTapped), for: .touchUpInside)
        case .globe:
            b.backgroundColor = UIColor(white: 0.18, alpha: 1)
            b.addTarget(self, action: #selector(handleInputModeList(from:with:)),
                        for: .allTouchEvents)
        case .toSymbols:
            b.backgroundColor = UIColor(white: 0.18, alpha: 1)
            b.addTarget(self, action: #selector(showSymbols), for: .touchUpInside)
        case .toLetters:
            b.backgroundColor = UIColor(white: 0.18, alpha: 1)
            b.addTarget(self, action: #selector(showLetters), for: .touchUpInside)
        }
        return b
    }

    private func refreshShiftAppearance() {
        // Letter titles reflect the shift state; the shift key
        // itself fills when locked.
        for row in keyboardStack.arrangedSubviews {
            guard let stack = row as? UIStackView else { continue }
            for case let b as UIButton in stack.arrangedSubviews {
                if b.accessibilityIdentifier == "shift" {
                    b.backgroundColor = (shiftState == .locked)
                        ? UIColor(white: 0.55, alpha: 1)
                        : UIColor(white: 0.18, alpha: 1)
                } else if let v = b.accessibilityValue, v.count == 1, v.first?.isLetter == true {
                    let letter = (shiftState == .off) ? v.lowercased() : v.uppercased()
                    b.setTitle(letter, for: .normal)
                }
            }
        }
    }

    // MARK: - Key actions (the only places text ever changes)

    @objc private func insertKey(_ sender: UIButton) {
        guard let raw = sender.accessibilityValue else { return }
        var text = raw
        if raw.count == 1, raw.first?.isLetter == true {
            text = (shiftState == .off) ? raw.lowercased() : raw.uppercased()
            if shiftState == .once {
                shiftState = .off
                refreshShiftAppearance()
            }
        }
        textDocumentProxy.insertText(text)
        updateCandidates()
    }

    @objc private func shiftTapped() {
        switch shiftState {
        case .off: shiftState = .once
        case .once: shiftState = .locked
        case .locked: shiftState = .off
        }
        refreshShiftAppearance()
    }

    @objc private func deleteTapped() {
        textDocumentProxy.deleteBackward()
        updateCandidates()
    }

    @objc private func spaceTapped() {
        // Space inserts a space. It never accepts a candidate.
        textDocumentProxy.insertText(" ")
        updateCandidates()
    }

    @objc private func returnTapped() {
        textDocumentProxy.insertText("\n")
        updateCandidates()
    }

    @objc private func showSymbols() {
        layer = .symbols
        buildRows()
    }

    @objc private func showLetters() {
        layer = .letters
        buildRows()
    }
}
