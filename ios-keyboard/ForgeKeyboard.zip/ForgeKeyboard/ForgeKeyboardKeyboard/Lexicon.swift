import Foundation

/// The personal lexicon, seeded in code.
///
/// Completion is prefix-based against this list plus the system
/// text checker. This list is data, not code paths: entries are
/// offered in the candidate bar exactly as written here, and are
/// inserted only on an explicit tap (see KeyboardViewController).
enum Lexicon {
    static let personal: [String] = [
        "infrastructure",
        "Jamf",
        "macOS",
        "endpoint",
        "Detroit",
        "Southfield",
        "AutomatedTechnologies",
        "detroitautomationacademy",
        "Geek Bar",
        "AT&T",
        "GitLab",
        "Terraform",
        "YAML",
        "configuration",
        "articulation",
    ]
}
