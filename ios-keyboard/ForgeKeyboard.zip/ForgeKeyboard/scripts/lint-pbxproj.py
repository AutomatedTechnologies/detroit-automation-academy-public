#!/usr/bin/env python3
"""Structural lint for project.pbxproj (OpenStep plist format).

Adapted from the Live Transit Detroit sibling project. Proves:
  * the file tokenizes and parses as an OpenStep plist,
  * rootObject resolves to the PBXProject; both targets, their
    build phases, build files, and file references cross-resolve
    (no dangling 24-hex object IDs),
  * the app target embeds the keyboard extension (PBXCopyFiles
    phase, dstSubfolderSpec 13) and depends on it,
  * every group-relative file reference exists on disk,
  * target build settings carry the contract values (bundle IDs,
    deployment target, Info.plist paths).

Does NOT prove Xcode accepts every implicit default; first open
on a Mac is the settling check (see README.md).
"""
import re
import sys
from pathlib import Path

PBX = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
    "ForgeKeyboard.xcodeproj/project.pbxproj")
PROJECT_DIR = PBX.parent.parent  # .xcodeproj -> project root

TEXT = PBX.read_text(encoding="utf-8")

TOKEN_RE = re.compile(r"""
    (?P<ws>\s+)
  | (?P<comment>/\*.*?\*/|//[^\n]*)
  | (?P<quoted>"(?:\\.|[^"\\])*")
  | (?P<punct>[{}()=;,])
  | (?P<word>[^\s{}()=;,]+)
""", re.VERBOSE | re.DOTALL)


def tokenize(text):
    tokens, pos = [], 0
    while pos < len(text):
        m = TOKEN_RE.match(text, pos)
        if not m:
            raise SyntaxError(f"untokenizable at offset {pos}: {text[pos:pos+40]!r}")
        pos = m.end()
        if m.lastgroup in ("ws", "comment"):
            continue
        value = m.group()
        if m.lastgroup == "quoted":
            value = bytes(value[1:-1], "utf-8").decode("unicode_escape")
        tokens.append(value)
    return tokens


class Parser:
    def __init__(self, tokens):
        self.tokens, self.i = tokens, 0

    def peek(self):
        return self.tokens[self.i] if self.i < len(self.tokens) else None

    def next(self):
        tok = self.peek()
        self.i += 1
        return tok

    def expect(self, tok):
        got = self.next()
        if got != tok:
            raise SyntaxError(f"expected {tok!r}, got {got!r}")

    def parse_value(self):
        tok = self.peek()
        if tok == "{":
            return self.parse_dict()
        if tok == "(":
            return self.parse_list()
        return self.next()

    def parse_dict(self):
        self.expect("{")
        out = {}
        while self.peek() != "}":
            key = self.next()
            self.expect("=")
            out[key] = self.parse_value()
            self.expect(";")
        self.expect("}")
        return out

    def parse_list(self):
        self.expect("(")
        out = []
        while self.peek() != ")":
            out.append(self.parse_value())
            if self.peek() == ",":
                self.next()
        self.expect(")")
        return out


root = Parser(tokenize(TEXT)).parse_value()
objects = root["objects"]
root_id = root["rootObject"]
failures = []


def check(cond, message):
    print(("PASS " if cond else "FAIL ") + message)
    if not cond:
        failures.append(message)


check(root.get("archiveVersion") == "1", "archiveVersion == 1")
check(root_id in objects and objects[root_id].get("isa") == "PBXProject",
      "rootObject resolves to PBXProject")

ID_RE = re.compile(r"^[0-9A-F]{24}$")


def walk(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for k, v in value.items():
            yield k
            yield from walk(v)
    elif isinstance(value, list):
        for v in value:
            yield from walk(v)


dangling = set()
for oid, obj in objects.items():
    for token in walk(obj):
        if ID_RE.match(token) and token not in objects:
            dangling.add(token)
check(not dangling, f"no dangling object IDs (found: {sorted(dangling) or 'none'})")

project = objects[root_id]
targets = {objects[t]["name"]: objects[t] for t in project["targets"]}
check(set(targets) == {"ForgeKeyboard", "ForgeKeyboardKeyboard"},
      f"two targets: app + keyboard extension ({sorted(targets)})")

app = targets["ForgeKeyboard"]
ext = targets["ForgeKeyboardKeyboard"]
check(objects[app["productReference"]].get("path") == "ForgeKeyboard.app",
      "app product is ForgeKeyboard.app")
check(objects[ext["productReference"]].get("path") == "ForgeKeyboardKeyboard.appex",
      "extension product is ForgeKeyboardKeyboard.appex")
check(ext.get("productType") == "com.apple.product-type.app-extension",
      "extension productType is app-extension")

# embed phase + dependency
copy_phases = [objects[p] for p in app["buildPhases"]
               if objects[p].get("isa") == "PBXCopyFilesBuildPhase"]
check(len(copy_phases) == 1 and copy_phases[0].get("dstSubfolderSpec") == "13",
      "app target has one Embed App Extensions copy phase (dstSubfolderSpec 13)")
if copy_phases:
    embedded = [objects[objects[f]["fileRef"]].get("path")
                for f in copy_phases[0]["files"]]
    check(embedded == ["ForgeKeyboardKeyboard.appex"],
          f"embed phase embeds the extension ({embedded})")
deps = [objects[d] for d in app.get("dependencies", [])]
check(any(objects[d["targetProxy"]].get("remoteInfo") == "ForgeKeyboardKeyboard"
          for d in deps if d.get("isa") == "PBXTargetDependency"),
      "app target depends on the extension target")

for name, target in targets.items():
    kinds = {objects[p]["isa"] for p in target["buildPhases"]}
    check({"PBXSourcesBuildPhase", "PBXFrameworksBuildPhase",
           "PBXResourcesBuildPhase"} <= kinds,
          f"{name} has Sources+Frameworks+Resources phases")

# files on disk
parent = {}
for oid, obj in objects.items():
    if obj.get("isa") == "PBXGroup":
        for child in obj.get("children", []):
            parent[child] = oid


def group_path(oid):
    parts = []
    while oid in parent:
        oid = parent[oid]
        obj = objects[oid]
        if obj.get("path"):
            parts.append(obj["path"])
    return Path(*reversed(parts)) if parts else Path()


missing = []
for oid, obj in objects.items():
    if obj.get("isa") != "PBXFileReference":
        continue
    if obj.get("sourceTree") != "<group>" or not obj.get("path"):
        continue
    full = PROJECT_DIR / group_path(oid) / obj["path"]
    if not full.exists():
        missing.append(str(full))
check(not missing, f"all group-relative file references exist on disk (missing: {missing or 'none'})")


def merged_settings(target):
    configs = objects[target["buildConfigurationList"]]["buildConfigurations"]
    out = {}
    for cid in configs:
        out.update(objects[cid]["buildSettings"])
    return out


app_s = merged_settings(app)
ext_s = merged_settings(ext)
check(app_s.get("PRODUCT_BUNDLE_IDENTIFIER") == "com.detroitautomationacademy.keyboard",
      "app bundle ID == com.detroitautomationacademy.keyboard")
check(ext_s.get("PRODUCT_BUNDLE_IDENTIFIER") == "com.detroitautomationacademy.keyboard.Keyboard",
      "extension bundle ID == com.detroitautomationacademy.keyboard.Keyboard")
check(app_s.get("IPHONEOS_DEPLOYMENT_TARGET") == "17.0"
      and ext_s.get("IPHONEOS_DEPLOYMENT_TARGET") == "17.0",
      "deployment target 17.0 on both targets")
check(app_s.get("INFOPLIST_FILE") == "ForgeKeyboard/Info.plist",
      "app INFOPLIST_FILE == ForgeKeyboard/Info.plist")
check(ext_s.get("INFOPLIST_FILE") == "ForgeKeyboardKeyboard/Info.plist",
      "extension INFOPLIST_FILE == ForgeKeyboardKeyboard/Info.plist")
check(app_s.get("ASSETCATALOG_COMPILER_APPICON_NAME") == "AppIcon",
      "app icon set named AppIcon")

print()
if failures:
    print(f"LINT FAILED: {len(failures)} check(s)")
    sys.exit(1)
print(f"LINT OK: {len(objects)} objects, all checks passed")
