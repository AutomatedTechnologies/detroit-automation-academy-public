# Forge Keyboard — iOS custom keyboard

A keyboard that types what you type. Container app + keyboard
extension, hand-written Xcode project. Bundle IDs:
`com.detroitautomationacademy.keyboard` (app) and
`com.detroitautomationacademy.keyboard.Keyboard` (extension).
Deployment target iOS 17, iPhone + iPad.

```
ForgeKeyboard/
  ForgeKeyboard.xcodeproj/          hand-written project (lint: scripts/lint-pbxproj.py)
  ForgeKeyboard/                    container app (SwiftUI)
    ForgeKeyboardApp.swift          @main
    ContentView.swift               the contract + enablement steps
    Assets.xcassets/                AppIcon (Academy grayscale mark) + launch color
    Info.plist
  ForgeKeyboardKeyboard/            the keyboard extension
    KeyboardViewController.swift    layout, candidate bar, all key actions
    Lexicon.swift                   the seeded personal vocabulary
    Info.plist                      NSExtension: keyboard service, RequestsOpenAccess = false
  scripts/
    lint-pbxproj.py                 structural check of the project file
```

## The contract

1. **No silent auto-substitution, ever.** Nothing typed is
   replaced without a tap. The candidate bar shows up to 3
   suggestions; a replacement is applied only when a candidate
   is tapped. Space and punctuation insert themselves and
   nothing else — they never accept a correction.
2. **No key flicks.** Plain QWERTY taps only, standard layout,
   shift (tap = once, tap again = lock), delete, return, a
   globe key for switching keyboards, and a 123 symbol layer.
   No long-press alternates, no gestures.
3. **A lexicon that knows your words.** Seeded in code:
   infrastructure, Jamf, macOS, endpoint, Detroit, Southfield,
   AutomatedTechnologies, detroitautomationacademy, Geek Bar,
   AT&T, GitLab, Terraform, YAML, configuration, articulation —
   plus standard English completion from the system's own
   UITextChecker. Completion is prefix-based: personal-lexicon
   matches first (exact prefix, curated order), then checker
   completions, deduplicated, capped at 3 — and never applied
   automatically (rule 1).

## Privacy

The keyboard requests **no Full Access**
(`RequestsOpenAccess` is `false` in the extension's Info.plist)
and does **no networking** — the extension's source contains no
network calls at all. Everything stays in the extension, on the
device.

## Build & install (Mac, Xcode 16) — the only remaining steps

Signing cannot happen on the Academy VM: iOS installs only
Apple-chained signatures, and the free route is Xcode with a
personal Apple ID (free provisioning; the profile expires after
7 days and the app is then reinstalled from Xcode the same way).

1. Download `ForgeKeyboard.zip` from the Academy page
   (https://www.detroitautomationacademy.com/ios-keyboard/) and
   unzip it on the Mac.
2. Open `ForgeKeyboard.xcodeproj` in Xcode.
3. Xcode → Settings → Accounts → sign in with your Apple ID
   (once; Xcode creates the free Personal Team).
4. Select the ForgeKeyboard target → Signing & Capabilities →
   "Automatically manage signing" → Team: your Personal Team.
   Do the same for the ForgeKeyboardKeyboard target if Xcode
   asks.
5. Connect the iPad, select it as the run destination, Run (⌘R).
6. On the iPad, if prompted: Settings → General → VPN & Device
   Management → the developer profile → Trust.
7. Settings → General → Keyboard → Keyboards → Add New
   Keyboard… → Forge Keyboard. Then hold the globe key in any
   app and pick Forge Keyboard.

## Verification done on the build VM (Linux)

- `scripts/lint-pbxproj.py`: 19/19 checks — project parses,
  object graph resolves with no dangling IDs, both targets and
  the Embed App Extensions phase are wired, every referenced
  file exists on disk, bundle IDs / deployment target /
  Info.plist paths match the contract.
- Both Info.plists parse as XML plists; the extension declares
  `com.apple.keyboard-service`, principal class
  `KeyboardViewController`, `RequestsOpenAccess = false`.
- Swift sources: manual review + delimiter-balance check. No
  Swift compiler exists on this VM, so no compile was run —
  first open in Xcode is the settling check.
