import SwiftUI

/// Forge Keyboard — container app.
///
/// The app itself does almost nothing: it explains what the
/// keyboard does, what it never does, and how to enable it.
/// The keyboard lives in the ForgeKeyboardKeyboard extension.
@main
struct ForgeKeyboardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
