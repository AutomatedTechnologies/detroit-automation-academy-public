import SwiftUI

/// The container app's only screen: the contract and the
/// enablement steps. Nothing here collects, sends, or stores
/// anything — the app has no networking code at all.
struct ContentView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Forge Keyboard")
                    .font(.largeTitle.bold())

                Text("A keyboard that types what you type.")
                    .font(.headline)
                    .foregroundStyle(.secondary)

                VStack(alignment: .leading, spacing: 10) {
                    Label("Nothing you type is ever replaced without your tap. "
                        + "The bar above the keys may offer up to three suggestions; "
                        + "a suggestion is inserted only when you tap it. Space and "
                        + "punctuation never accept a correction.",
                          systemImage: "hand.tap")
                    Label("Plain QWERTY taps only. No key flicks, no hidden "
                        + "characters, no gestures that insert something else.",
                          systemImage: "keyboard")
                    Label("Your vocabulary is built in: infrastructure, Jamf, "
                        + "macOS, endpoint, Detroit, Southfield, "
                        + "AutomatedTechnologies, GitLab, Terraform, YAML — "
                        + "and completion from the system's own checker.",
                          systemImage: "text.book.closed")
                }
                .font(.subheadline)

                Divider()

                VStack(alignment: .leading, spacing: 8) {
                    Text("Privacy")
                        .font(.headline)
                    Text("Forge Keyboard requests no Full Access and does no "
                        + "networking. Keystrokes stay in the extension, on this "
                        + "device. There is nothing to phone home with — the code "
                        + "contains no network calls.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Divider()

                VStack(alignment: .leading, spacing: 8) {
                    Text("Turn it on")
                        .font(.headline)
                    Text("1. Settings → General → Keyboard → Keyboards\n"
                        + "2. Add New Keyboard… → Forge Keyboard\n"
                        + "3. In any app, hold the globe key and pick Forge Keyboard.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(24)
        }
        .preferredColorScheme(.dark)
    }
}
